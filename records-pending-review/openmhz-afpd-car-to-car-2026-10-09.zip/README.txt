OpenMHz AFPD Car-to-Car (6001), 2026-10-09, America/Denver.
Metadata schema: 1.
Coverage: complete; collected through 2026-10-10T06:00:00Z.
327 unique audio files; 327 source call entries.
Source: OpenMHz (https://openmhz.com/). Original audio bytes and filenames retained.
calls.json: chronological call metadata, original source IDs/labels, timestamps and audio checks.
rows.json: source labels in chronological unique-audio order.
validation.json: coverage and audio-validation results, plus preserved historical evidence.
Unix timestamps determine Mountain times; original browser labels may use another timezone.
